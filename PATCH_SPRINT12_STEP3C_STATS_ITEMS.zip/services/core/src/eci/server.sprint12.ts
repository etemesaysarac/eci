/*
Sprint 12 — Claims / İade
========================

Scope (STEP-3A):
  - Enqueue a single SYNC job that pulls claims from Trendyol (GET getClaims)
  - Persist Claim + ClaimItem rows via worker

Endpoints (this file):
  - POST /v1/connections/:id/sync/claims

Notes:
  - Uses the same per-connection sync lock (eci:sync:lock:<connectionId>)
  - This is intentionally small: approve/reject/audits/read endpoints will come next.
*/

import type { Request, Response } from "express";
import asyncHandler from "express-async-handler";
import IORedis from "ioredis";
import { randomUUID } from "crypto";
import { z } from "zod";

import { eciQueue } from "./queue";
import { prisma } from "./prisma";

const REDIS_URL = process.env.REDIS_URL ?? "redis://localhost:6379";
const SYNC_LOCK_TTL_MS = Number(process.env.SYNC_LOCK_TTL_MS ?? 60 * 60 * 1000);
const redis = new IORedis(REDIS_URL, { maxRetriesPerRequest: null });

function syncLockKey(connectionId: string) {
  return `eci:sync:lock:${connectionId}`;
}

const SyncClaimsSchema = z
  .object({
    // claimItemStatus on Trendyol side (optional)
    status: z.string().optional(),
    startDate: z.number().int().optional(),
    endDate: z.number().int().optional(),
    pageSize: z.number().int().min(1).max(200).optional(),
  })
  .strict()
  .optional();

const ReadClaimsQuerySchema = z
  .object({
    connectionId: z.string().min(1),
    status: z.string().optional(),
    page: z.coerce.number().int().min(0).optional(),
    pageSize: z.coerce.number().int().min(1).max(200).optional(),
  })
  .strict();

const ReadClaimDetailQuerySchema = z
  .object({
    connectionId: z.string().min(1),
  })
  .strict();

const ReadClaimAuditsQuerySchema = z
  .object({
    connectionId: z.string().min(1),
  })
  .strict();


// list claim items for UI (optional filters + pagination)
const ReadClaimItemsQuerySchema = z
  .object({
    connectionId: z.string().min(1),
    claimId: z.string().optional(),
    itemStatus: z.string().optional(),
    page: z.coerce.number().int().min(0).optional(),
    pageSize: z.coerce.number().int().min(1).max(200).optional(),
  })
  .strict();

// lightweight stats for dashboard / quick sanity checks
const ReadClaimStatsQuerySchema = z
  .object({
    connectionId: z.string().min(1),
  })
  .strict();

export function registerSprint12ClaimRoutes(app: any) {
  /**
   * POST /v1/connections/:id/sync/claims
   * Body (optional): { status?, startDate?, endDate?, pageSize? }
   */
  app.post(
    "/v1/connections/:id/sync/claims",
    asyncHandler(async (req: Request, res: Response) => {
      const id = String(req.params.id ?? "");

      const conn = await prisma.connection.findUnique({
        where: { id },
        select: { id: true, type: true },
      });
      if (!conn) return res.status(404).json({ error: "not_found" });
      if (conn.type !== "trendyol") return res.status(400).json({ error: "only trendyol supported for now" });

      const parsed = SyncClaimsSchema?.safeParse(req.body);
      if (parsed && !parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
      const body = parsed?.success ? parsed.data ?? undefined : undefined;

      // Concurrency guard: connection bazlı tek aktif sync
      const lockKey = syncLockKey(id);
      const pending = `pending:${randomUUID()}`;
      const acquired = await redis.set(lockKey, pending, "PX", SYNC_LOCK_TTL_MS, "NX");
      if (acquired !== "OK") {
        const active = await prisma.job.findFirst({
          where: {
            connectionId: id,
            type: { in: ["TRENDYOL_SYNC_ORDERS", "TRENDYOL_SYNC_CLAIMS"] },
            status: { in: ["queued", "running", "retrying"] },
          },
          orderBy: { createdAt: "desc" },
          select: { id: true, status: true, createdAt: true, type: true },
        });

        return res.status(409).json({
          error: "sync_in_progress",
          connectionId: id,
          jobId: active?.id,
          status: active?.status,
          type: active?.type,
          createdAt: active?.createdAt,
        });
      }

      let jobRow: { id: string } | null = null;
      try {
        jobRow = await prisma.job.create({
          data: {
            connectionId: id,
            type: "TRENDYOL_SYNC_CLAIMS",
            status: "queued",
          },
          select: { id: true },
        });

        // lock owner'ı gerçek jobId yapalım (worker release edebilsin)
        await redis.set(lockKey, jobRow.id, "PX", SYNC_LOCK_TTL_MS);

        await eciQueue.add(
          "TRENDYOL_SYNC_CLAIMS",
          { jobId: jobRow.id, connectionId: id, params: body ?? null },
          {
            // Stabilizasyon: bir hata oldu diye direkt "failed" olmasın.
            attempts: 5,
            backoff: { type: "exponential", delay: 1000 },
            removeOnComplete: 1000,
            removeOnFail: 1000,
          }
        );

        return res.json({ jobId: jobRow.id });
      } catch (e: any) {
        await redis.del(lockKey);
        if (jobRow?.id) {
          await prisma.job.update({
            where: { id: jobRow.id },
            data: { status: "failed", finishedAt: new Date(), error: String(e?.message ?? e) },
          });
        }
        throw e;
      }
    })
  );

  /**
   * Read list (panel)
   * GET /v1/claims?connectionId=...&status=...&page=0&pageSize=50
   */
  app.get(
    "/v1/claims",
    asyncHandler(async (req: Request, res: Response) => {
      const parsed = ReadClaimsQuerySchema.safeParse(req.query);
      if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

      const { connectionId, status } = parsed.data;
      const page = parsed.data.page ?? 0;
      const pageSize = parsed.data.pageSize ?? 50;

      const rows = await prisma.claim.findMany({
        where: {
          connectionId,
          marketplace: "trendyol",
          ...(status ? { status } : {}),
        },
        orderBy: [{ lastModifiedAt: "desc" }, { updatedAt: "desc" }],
        skip: page * pageSize,
        take: pageSize,
        select: {
          id: true,
          claimId: true,
          status: true,
          orderNumber: true,
          claimDate: true,
          lastModifiedAt: true,
          updatedAt: true,
          _count: { select: { items: true } },
        },
      });

      return res.json({
        page,
        pageSize,
        items: rows.map((r) => ({
          id: r.id,
          claimId: r.claimId,
          status: r.status,
          orderNumber: r.orderNumber,
          claimDate: r.claimDate,
          lastModifiedAt: r.lastModifiedAt,
          updatedAt: r.updatedAt,
          itemCount: r._count.items,
        })),
      });
    })
  );

  
  /**
   * Read stats (panel)
   * GET /v1/claims/stats?connectionId=...
   */
  app.get(
    "/v1/claims/stats",
    asyncHandler(async (req, res) => {
      const parsed = ReadClaimStatsQuerySchema.safeParse(req.query);
      if (!parsed.success) return res.status(400).json({ error: parsed.error.format() });

      const { connectionId } = parsed.data;

      const [claimTotal, claimGroups, itemTotal, itemGroups] = await Promise.all([
        prisma.claim.count({ where: { connectionId, marketplace: "trendyol" } }),
        prisma.claim.groupBy({
          by: ["status"],
          where: { connectionId, marketplace: "trendyol" },
          _count: { _all: true },
        }),
        prisma.claimItem.count({ where: { connectionId, marketplace: "trendyol" } }),
        prisma.claimItem.groupBy({
          by: ["itemStatus"],
          where: { connectionId, marketplace: "trendyol" },
          _count: { _all: true },
        }),
      ]);

      const claimsByStatus: Record<string, number> = {};
      for (const g of claimGroups) {
        const key = String((g as any).status ?? "UNKNOWN");
        claimsByStatus[key] = (g as any)._count?._all ?? 0;
      }

      const itemsByStatus: Record<string, number> = {};
      for (const g of itemGroups) {
        const key = String((g as any).itemStatus ?? "UNKNOWN");
        itemsByStatus[key] = (g as any)._count?._all ?? 0;
      }

      return res.json({
        connectionId,
        claims: { total: claimTotal, byStatus: claimsByStatus },
        items: { total: itemTotal, byStatus: itemsByStatus },
        updatedAt: new Date().toISOString(),
      });
    })
  );

  /**
   * Read claim items (panel)
   * GET /v1/claims/items?connectionId=...&claimId=...&itemStatus=...&page=0&pageSize=50
   */
  app.get(
    "/v1/claims/items",
    asyncHandler(async (req, res) => {
      const parsed = ReadClaimItemsQuerySchema.safeParse(req.query);
      if (!parsed.success) return res.status(400).json({ error: parsed.error.format() });

      const { connectionId, claimId, itemStatus } = parsed.data;
      const page = parsed.data.page ?? 0;
      const pageSize = parsed.data.pageSize ?? 50;

      const where: any = { connectionId, marketplace: "trendyol" };
      if (claimId) where.claimId = claimId;
      if (itemStatus) where.itemStatus = itemStatus;

      const [total, items] = await Promise.all([
        prisma.claimItem.count({ where }),
        prisma.claimItem.findMany({
          where,
          orderBy: { updatedAt: "desc" },
          skip: page * pageSize,
          take: pageSize,
          select: {
            claimId: true,
            claimItemId: true,
            sku: true,
            barcode: true,
            quantity: true,
            itemStatus: true,
            reasonCode: true,
            reasonName: true,
            createdAt: true,
            updatedAt: true,
          },
        }),
      ]);

      return res.json({ page, pageSize, total, items });
    })
  );
/**
   * Read detail (panel)
   * GET /v1/claims/:claimId?connectionId=...
   */
  app.get(
    "/v1/claims/:claimId",
    asyncHandler(async (req: Request, res: Response) => {
      const claimId = String(req.params.claimId ?? "");
      const parsed = ReadClaimDetailQuerySchema.safeParse(req.query);
      if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
      const { connectionId } = parsed.data;

      const row = await prisma.claim.findFirst({
        where: { connectionId, marketplace: "trendyol", claimId },
        select: {
          id: true,
          claimId: true,
          status: true,
          orderNumber: true,
          claimDate: true,
          lastModifiedAt: true,
          raw: true,
          items: {
            orderBy: [{ updatedAt: "desc" }],
            select: {
              id: true,
              claimItemId: true,
              claimId: true,
              barcode: true,
              sku: true,
              quantity: true,
              itemStatus: true,
              reasonCode: true,
              reasonName: true,
              updatedAt: true,
            },
          },
        },
      });

      if (!row) return res.status(404).json({ error: "not_found" });
      return res.json(row);
    })
  );

  /**
   * Read audits for a claimItemId (remote id)
   * GET /v1/claims/items/:claimItemId/audits?connectionId=...
   */
  app.get(
    "/v1/claims/items/:claimItemId/audits",
    asyncHandler(async (req: Request, res: Response) => {
      const claimItemId = String(req.params.claimItemId ?? "");
      const parsed = ReadClaimAuditsQuerySchema.safeParse(req.query);
      if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
      const { connectionId } = parsed.data;

      const item = await prisma.claimItem.findFirst({
        where: { connectionId, marketplace: "trendyol", claimItemId },
        select: { id: true },
      });
      if (!item) return res.status(404).json({ error: "not_found" });

      const audits = await prisma.claimAudit.findMany({
        where: { connectionId, marketplace: "trendyol", claimItemDbId: item.id },
        orderBy: [{ date: "asc" }],
        select: {
          previousStatus: true,
          newStatus: true,
          executorApp: true,
          executorUser: true,
          date: true,
          raw: true,
        },
      });

      return res.json({ claimItemId, audits });
    })
  );
}
